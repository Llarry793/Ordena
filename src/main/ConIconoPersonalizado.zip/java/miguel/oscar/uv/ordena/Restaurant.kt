package miguel.oscar.uv.ordena

import android.os.Parcel
import android.os.Parcelable

data class Restaurant(
    val id: Long,
    val name: String,
    val description: String,
    val imageResId: Int = R.mipmap.ic_launcher,
    val imagePath: String? = null,
    val address: String? = null
) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readLong(),
        parcel.readString()!!,
        parcel.readString()!!,
        parcel.readInt(),
        parcel.readString(),
        parcel.readString()
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeLong(id)
        parcel.writeString(name)
        parcel.writeString(description)
        parcel.writeInt(imageResId)
        parcel.writeString(imagePath)
        parcel.writeString(address)

    }

    override fun describeContents(): Int = 0

    companion object CREATOR : Parcelable.Creator<Restaurant> {
        override fun createFromParcel(parcel: Parcel): Restaurant = Restaurant(parcel)
        override fun newArray(size: Int): Array<Restaurant?> = arrayOfNulls(size)
    }
}