package miguel.oscar.uv.ordena

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView

class ProductActivity : AppCompatActivity() {

    private lateinit var dbHelper: RestaurantDbHelper
    private lateinit var db: SQLiteDatabase
    private lateinit var adapter: ProductAdapter
    private lateinit var restaurantName: String
    private lateinit var unit: String
    private var quantity: Double = 0.0
    private var restaurantId: Long = -1L
    private lateinit var bottomNavigation: BottomNavigationView
    private var currentRestaurantId: Long = -1L
    private var currentRestaurantName: String = ""
    private var currentRestaurantAddress: String? = null

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_product)

        dbHelper = RestaurantDbHelper(this)
        db = dbHelper.writableDatabase

        // Obtener el ID y nombre del restaurante
        restaurantId = intent.getLongExtra("restaurant_id", -1L)
        restaurantName = intent.getStringExtra("restaurant_name") ?: ""

        // Obtener datos del restaurante desde el Intent
        currentRestaurantId = intent.getLongExtra("restaurant_id", -1L)
        currentRestaurantName = intent.getStringExtra("restaurant_name") ?: ""

        // Verificar que el ID del restaurante sea válido
        if (restaurantId == -1L) {
            Toast.makeText(this, "Error: ID de restaurante no válido", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        // Obtener la dirección del restaurante actual desde la base de datos
        currentRestaurantAddress = getRestaurantAddress(currentRestaurantId)

        val title = findViewById<TextView>(R.id.restaurantTitle)
        title.text = restaurantName

        setupRecyclerView()
        loadProducts()

        val addButton = findViewById<Button>(R.id.addProductButton)
        val productInput = findViewById<EditText>(R.id.productInput)
        val unitSpinner = findViewById<Spinner>(R.id.unitSpinner)
        val quantityInput = findViewById<EditText>(R.id.quantityInput)

        addButton.setOnClickListener {
            val productName = productInput.text.toString().trim()
            val unit = unitSpinner.selectedItem.toString()
            val quantityText = quantityInput.text.toString()

            if (productName.isEmpty()) {
                Toast.makeText(this, "Nombre requerido", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val quantity = try {
                quantityText.toDouble().coerceAtLeast(0.0)
            } catch (e: NumberFormatException) {
                0.0
            }

            val productId = insertProduct(productName, unit, quantity)
            if (productId != -1L) {
                adapter.addProduct(Product(productId, productName, unit, quantity, restaurantId))
                productInput.text.clear()
                quantityInput.text.clear()
            }
        }

        bottomNavigation = findViewById(R.id.bottom_navigation)
        bottomNavigation.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_map -> {
                    // Crear una lista con solo el restaurante actual
                    if (currentRestaurantAddress != null) {
                        val currentRestaurant = Restaurant(
                            currentRestaurantId,
                            currentRestaurantName,
                            "",  // No necesitamos la descripción para el mapa
                            R.mipmap.ic_launcher,
                            null,
                            currentRestaurantAddress
                        )
                        val restaurantList = ArrayList<Restaurant>().apply {
                            add(currentRestaurant)
                        }

                        val intent = Intent(this, RestaurantMapActivity::class.java).apply {
                            putParcelableArrayListExtra("restaurants", restaurantList)
                        }
                        startActivity(intent)
                    } else {
                        Toast.makeText(this, "Este restaurante no tiene dirección", Toast.LENGTH_SHORT).show()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun getRestaurantAddress(restaurantId: Long): String? {
        var address: String? = null
        try {
            val cursor = db.query(
                RestaurantContract.TABLE_NAME,
                arrayOf(RestaurantContract.COLUMN_ADDRESS),
                "${RestaurantContract.COLUMN_ID} = ?",
                arrayOf(restaurantId.toString()),
                null, null, null
            )

            if (cursor.moveToFirst()) {
                address = cursor.getString(cursor.getColumnIndexOrThrow(RestaurantContract.COLUMN_ADDRESS))
            }
            cursor.close()
        } catch (e: Exception) {
            Toast.makeText(this, "Error al obtener la dirección: ${e.message}", Toast.LENGTH_SHORT).show()
        }
        return address
    }

    private fun setupRecyclerView() {
        val recyclerView = findViewById<RecyclerView>(R.id.productRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = ProductAdapter(mutableListOf(), ::deleteProduct)
        recyclerView.adapter = adapter
    }

    private fun loadProducts() {
        try {
            val cursor = db.query(
                ProductContract.TABLE_NAME,
                arrayOf(
                    ProductContract.COLUMN_ID,
                    ProductContract.COLUMN_NAME,
                    ProductContract.COLUMN_UNIT,
                    ProductContract.COLUMN_QUANTITY,
                    ProductContract.COLUMN_RESTAURANT_ID
                ),
                "${ProductContract.COLUMN_RESTAURANT_ID} = ?",
                arrayOf(restaurantId.toString()),
                null, null, null
            )

            val products = mutableListOf<Product>()
            with(cursor) {
                while (moveToNext()) {
                    products.add(
                        Product(
                            id = getLong(getColumnIndexOrThrow(ProductContract.COLUMN_ID)),
                            name = getString(getColumnIndexOrThrow(ProductContract.COLUMN_NAME)),
                            unit = getString(getColumnIndexOrThrow(ProductContract.COLUMN_UNIT)),
                            quantity = getDouble(getColumnIndexOrThrow(ProductContract.COLUMN_QUANTITY)),
                            restaurantId = restaurantId
                        )
                    )
                }
            }
            cursor.close()
            adapter.updateProducts(products)
        } catch (e: Exception) {
            Toast.makeText(this, "Error al cargar productos: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun insertProduct(name: String, unit: String, quantity: Double): Long {
        val values = ContentValues().apply {
            put(ProductContract.COLUMN_NAME, name)
            put(ProductContract.COLUMN_UNIT, unit)
            put(ProductContract.COLUMN_QUANTITY, quantity)
            put(ProductContract.COLUMN_RESTAURANT_ID, restaurantId)
        }
        return db.insert(ProductContract.TABLE_NAME, null, values)
    }

    private fun deleteProduct(product: Product) {
        db.delete(
            ProductContract.TABLE_NAME,
            "${ProductContract.COLUMN_ID} = ?",
            arrayOf(product.id.toString())
        )
    }
}
