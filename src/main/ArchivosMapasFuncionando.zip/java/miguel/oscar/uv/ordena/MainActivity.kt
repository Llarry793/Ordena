package miguel.oscar.uv.ordena

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import java.io.File
import androidx.recyclerview.widget.ItemTouchHelper
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: RestaurantAdapter
    private val restaurantList = mutableListOf<Restaurant>()
    private lateinit var dbHelper: RestaurantDbHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        dbHelper = RestaurantDbHelper(this)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = RestaurantAdapter(restaurantList) { restaurant ->
            val intent = Intent(this, ProductActivity::class.java).apply {
                putExtra("restaurant_id", restaurant.id) // Usar el ID real de la base de datos
                putExtra("restaurant_name", restaurant.name)
            }
            startActivity(intent)
        }
        recyclerView.adapter = adapter
        loadRestaurantsFromDatabase()

        // Configurar el swipe to delete
        setupSwipeToDelete()

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNavigationView)

        // En el método onCreate de MainActivity
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_anadir -> {
                    val intent = Intent(this, AddRestaurantActivity::class.java)
                    startActivityForResult(intent, ADD_RESTAURANT_REQUEST)
                    true
                }
                R.id.nav_map -> {
                    val intent = Intent(this, RestaurantMapActivity::class.java).apply {
                        putParcelableArrayListExtra("restaurants", ArrayList(restaurantList))
                    }
                    startActivity(intent)
                    true
                }
                else -> false
            }
        }


    }

    private fun setupSwipeToDelete() {
        val swipeToDeleteCallback = object : ItemTouchHelper.SimpleCallback(
            0, // No permitimos arrastrar (drag)
            ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT // Permitimos deslizar en ambas direcciones
        ) {
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                return false // No implementamos movimiento (drag)
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val position = viewHolder.adapterPosition
                val restaurant = restaurantList[position]

                // Eliminar de la base de datos
                val db = dbHelper.writableDatabase
                db.delete(
                    RestaurantContract.TABLE_NAME,
                    "${RestaurantContract.COLUMN_ID} = ?",
                    arrayOf(restaurant.id.toString())
                )

                // Eliminar de la lista y notificar al adaptador
                restaurantList.removeAt(position)
                adapter.notifyItemRemoved(position)

                // Mostrar un Snackbar con opción de deshacer
                Snackbar.make(
                    recyclerView,
                    "Restaurante eliminado",
                    Snackbar.LENGTH_LONG
                ).setAction("Deshacer") {
                    // Recuperar el restaurante eliminado
                    val values = ContentValues().apply {
                        put(RestaurantContract.COLUMN_NAME, restaurant.name)
                        put(RestaurantContract.COLUMN_DESCRIPTION, restaurant.description)
                        put(RestaurantContract.COLUMN_IMAGE_RES_ID, restaurant.imageResId)
                        if (restaurant.imagePath != null) {
                            put(RestaurantContract.COLUMN_IMAGE_PATH, restaurant.imagePath)
                        }
                    }

                    // Insertar de nuevo en la base de datos
                    val newRowId = db.insert(RestaurantContract.TABLE_NAME, null, values)

                    // Añadir de nuevo a la lista y notificar al adaptador
                    if (newRowId != -1L) {
                        restaurantList.add(position, Restaurant(newRowId, restaurant.name, restaurant.description, restaurant.imageResId, restaurant.imagePath))
                        adapter.notifyItemInserted(position)
                    }
                }.show()
            }
        }

        // Adjuntar el callback al RecyclerView
        val itemTouchHelper = ItemTouchHelper(swipeToDeleteCallback)
        itemTouchHelper.attachToRecyclerView(recyclerView)
    }

    private fun loadRestaurantsFromDatabase() {
        val db = dbHelper.readableDatabase

        val projection = arrayOf(
            RestaurantContract.COLUMN_ID,
            RestaurantContract.COLUMN_NAME,
            RestaurantContract.COLUMN_DESCRIPTION,
            RestaurantContract.COLUMN_IMAGE_RES_ID,
            RestaurantContract.COLUMN_IMAGE_PATH,
            RestaurantContract.COLUMN_ADDRESS
        )

        val cursor = db.query(
            RestaurantContract.TABLE_NAME,
            projection,
            null,
            null,
            null,
            null,
            null
        )

        restaurantList.clear()
        with(cursor) {
            while (moveToNext()) {
                val id = getLong(getColumnIndexOrThrow(RestaurantContract.COLUMN_ID))
                val name = getString(getColumnIndexOrThrow(RestaurantContract.COLUMN_NAME))
                val description = getString(getColumnIndexOrThrow(RestaurantContract.COLUMN_DESCRIPTION))
                val imageResId = getInt(getColumnIndexOrThrow(RestaurantContract.COLUMN_IMAGE_RES_ID))
                val imagePath = getString(getColumnIndexOrThrow(RestaurantContract.COLUMN_IMAGE_PATH))
                val address = getString(getColumnIndexOrThrow(RestaurantContract.COLUMN_ADDRESS))
                restaurantList.add(Restaurant(id, name, description, imageResId, imagePath, address))
            }
        }
        cursor.close()
        adapter.notifyDataSetChanged()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == ADD_RESTAURANT_REQUEST && resultCode == Activity.RESULT_OK) {
            data?.let { intent ->
                try {
                    val name = intent.getStringExtra("name") ?: ""
                    val description = intent.getStringExtra("description") ?: ""
                    val address = intent.getStringExtra("address") ?: ""
                    val photoPath = intent.getStringExtra("photoPath")

                    val db = dbHelper.writableDatabase
                    val values = ContentValues().apply {
                        put(RestaurantContract.COLUMN_NAME, name)
                        put(RestaurantContract.COLUMN_DESCRIPTION, description)
                        put(RestaurantContract.COLUMN_ADDRESS, address)
                        put(RestaurantContract.COLUMN_IMAGE_RES_ID, R.mipmap.ic_launcher)
                        photoPath?.let { put(RestaurantContract.COLUMN_IMAGE_PATH, it) }
                    }

                    val newRowId = db.insert(RestaurantContract.TABLE_NAME, null, values)
                    if (newRowId != -1L) {
                        restaurantList.add(Restaurant(
                            newRowId,
                            name,
                            description,
                            R.mipmap.ic_launcher,
                            photoPath,
                            address
                        ))
                        adapter.notifyItemInserted(restaurantList.size - 1)
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "Error al guardar: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    companion object {
        private const val ADD_RESTAURANT_REQUEST = 1
    }
}