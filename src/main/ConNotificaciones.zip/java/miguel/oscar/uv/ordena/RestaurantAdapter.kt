// RestaurantAdapter.kt
package miguel.oscar.uv.ordena

import android.graphics.BitmapFactory
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class RestaurantAdapter(
    private val restaurantList: List<Restaurant>,
    private val onItemClick: (Restaurant) -> Unit
) : RecyclerView.Adapter<RestaurantAdapter.RestaurantViewHolder>() {

    class RestaurantViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imageView: ImageView = itemView.findViewById(R.id.restaurantImage)
        val nameView: TextView = itemView.findViewById(R.id.restaurantName)
        val descriptionView: TextView = itemView.findViewById(R.id.restaurantDescription)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RestaurantViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_restaurant, parent, false)
        return RestaurantViewHolder(view)
    }

    override fun onBindViewHolder(holder: RestaurantViewHolder, position: Int) {
        val restaurant = restaurantList[position]
        // Cargar imagen desde archivo si existe
        restaurant.imagePath?.let { path ->
            val bitmap = BitmapFactory.decodeFile(path)
            holder.imageView.setImageBitmap(bitmap)
        } ?: run {
            holder.imageView.setImageResource(restaurant.imageResId)
        }

        holder.nameView.text = restaurant.name
        holder.descriptionView.text = restaurant.description
        holder.itemView.setOnClickListener {
            onItemClick(restaurant)
        }
    }

    override fun getItemCount() = restaurantList.size

    // Nuevo método para eliminar elementos
    fun removeItem(position: Int) {
        if (restaurantList is MutableList) {
            (restaurantList as MutableList<Restaurant>).removeAt(position)
            notifyItemRemoved(position)
        }
    }
}
