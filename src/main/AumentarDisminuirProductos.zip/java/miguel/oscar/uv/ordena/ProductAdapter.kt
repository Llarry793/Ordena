package miguel.oscar.uv.ordena

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ProductAdapter(
    private var productList: MutableList<Product>,
    private val onProductDeleted: (Product) -> Unit,
    private val onProductQuantityChanged: (Product, Double) -> Unit
) : RecyclerView.Adapter<ProductAdapter.ProductViewHolder>() {

    class ProductViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val productName: TextView = itemView.findViewById(R.id.productName)
        val productUnit: TextView = itemView.findViewById(R.id.productUnit)
        val productQuantity: TextView = itemView.findViewById(R.id.productQuantity)
        val deleteButton: TextView = itemView.findViewById(R.id.deleteButton)
        val incrementButton: TextView = itemView.findViewById(R.id.incrementButton)
        val decrementButton: TextView = itemView.findViewById(R.id.decrementButton)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_product, parent, false)
        return ProductViewHolder(view)
    }

    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        val product = productList[position]
        holder.productName.text = product.name
        holder.productUnit.text = product.unit
        holder.productQuantity.text = "%.2f".format(product.quantity)

        holder.deleteButton.setOnClickListener {
            onProductDeleted(product)
            productList.removeAt(position)
            notifyItemRemoved(position)
        }

        // Manejar clic en botón de incremento
        holder.incrementButton.setOnClickListener {
            val newQuantity = product.quantity + 1.0
            updateProductQuantity(product, newQuantity, position)
        }

        // Manejar clic en botón de decremento
        holder.decrementButton.setOnClickListener {
            if (product.quantity > 0) {
                val newQuantity = product.quantity - 1.0
                updateProductQuantity(product, newQuantity, position)
            }
        }
    }

    private fun updateProductQuantity(product: Product, newQuantity: Double, position: Int) {
        val updatedProduct = Product(
            id = product.id,
            name = product.name,
            unit = product.unit,
            quantity = newQuantity,
            restaurantId = product.restaurantId
        )
        onProductQuantityChanged(updatedProduct, newQuantity)
        productList[position] = updatedProduct
        notifyItemChanged(position)
    }

    override fun getItemCount() = productList.size

    fun addProduct(product: Product) {
        productList.add(product)
        notifyItemInserted(productList.size - 1)
    }

    //Metodo nuevo para actualizar la lista de productos
    fun updateProducts(newProducts: List<Product>) {
        productList.clear()
        productList.addAll(newProducts)
        notifyDataSetChanged()
    }
}
